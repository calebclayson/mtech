const pokemon2 = [
    {
        name: 'ditto',
        type: 'normal'
    },
    {
        name: 'mewtwo',
        type: 'normal'
    },
    {
        name: 'magikarp',
        type: 'water'
    },
    {
        name: 'pichu',
        type: 'electric'
    },
    {
        name: 'slowpoke',
        type: 'water'
    },
    {
        name: 'blastoise',
        type: 'water'
    },
    {
        name: 'jynx',
        type: 'psychic'
    },
    {
        name: 'greninja',
        type: 'water'
    },
    {
        name: 'onix',
        type: 'steel'
    },
    {
        name: 'spinda',
        type: 'normal'
    },
    {
        name: 'lapras',
        type: 'water'
    },
    {
        name: 'raikou',
        type: 'electric'
    },
    {
        name: 'ho-oh',
        type: 'normal'
    },
    {
        name: 'metagross',
        type: 'water'
    },
];

export {pokemon2};