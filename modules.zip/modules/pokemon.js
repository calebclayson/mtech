const pokemon = [
    {
        name: 'pikachu',
        type: 'electric'
    },
    {
        name: 'raichu',
        type: 'electric'
    },
    {
        name: 'zapdos',
        type: 'electric'
    },
    {
        name: 'charmander',
        type: 'fire'
    },
    {
        name: 'squirtle',
        type: 'water'
    },
    {
        name: 'bulbasaur',
        type: 'grass'
    },
    {
        name: 'eevee',
        type: 'normal'
    },
    {
        name: 'abra',
        type: 'psychic'
    },
    {
        name: 'pidgey',
        type: 'flying'
    },
    {
        name: 'machamp',
        type: 'fighting'
    },
    {
        name: 'caterpie',
        type: 'bug'
    },
    {
        name: 'honedge',
        type: 'steel'
    },
    {
        name: 'tepig',
        type: 'fire'
    },
    {
        name: 'oshawott',
        type: 'water'
    },
    {
        name: 'magmar',
        type: 'fire'
    },
    {
        name: 'electabuzz',
        type: 'electric'
    },
    {
        name: 'lugia',
        type: 'flying'
    },
];

export {pokemon};